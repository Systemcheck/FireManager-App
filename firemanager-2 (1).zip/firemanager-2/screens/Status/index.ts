import StatusScreen from "./StatusScreen";
import strings from "./strings";

export { strings };

export default StatusScreen;